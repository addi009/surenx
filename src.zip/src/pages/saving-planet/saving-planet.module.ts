import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { SavingPlanetPage } from './saving-planet';

@NgModule({
  declarations: [
    SavingPlanetPage,
  ],
  imports: [
    IonicPageModule.forChild(SavingPlanetPage),
  ],
})
export class SavingPlanetPageModule {}
