import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { DetailCommunityPage } from './detail-community';

@NgModule({
  declarations: [
    DetailCommunityPage,
  ],
  imports: [
    IonicPageModule.forChild(DetailCommunityPage),
  ],
})
export class DetailCommunityPageModule {}
