import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { DetailMarketPage } from './detail-market';

@NgModule({
  declarations: [
    DetailMarketPage,
  ],
  imports: [
    IonicPageModule.forChild(DetailMarketPage),
  ],
})
export class DetailMarketPageModule {}
